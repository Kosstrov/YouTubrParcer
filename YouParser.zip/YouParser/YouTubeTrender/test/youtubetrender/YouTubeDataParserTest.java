/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package youtubetrender;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 *
 * @author Carl
 */
public class YouTubeDataParserTest {

    public YouTubeDataParserTest() {
    }

    @BeforeClass
    public static void setUpClass() {

    }

    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of parse method, of class YouTubeDataParser.
     * This is for testing parsing JSON file.
     */
    @Test
    public void testParse() throws Exception {
        //System.out.println("parse");
        String fileName = "src/data/youtubedata_15_50.json";
        YouTubeDataParser instance = new YouTubeDataParser();
        List<YouTubeVideo> expResult = YouTubeDataParser.parse("src/data/youtubedata_15_50.json");
        List<YouTubeVideo> result = instance.parse(fileName);
        assertEquals(expResult.size(), 50);
    }

    /**
     * Test the ParseException.
     *
     * @throws Exception when the file cannot be opened or cannot be parsed
     */
    @Test(expected = Exception.class)
    public void testParseMalformedJSON() throws Exception {
        String fileName = "src/data/youtubedata_malformed.json";
        YouTubeDataParser instance = new YouTubeDataParser();
        List<YouTubeVideo> expResult = YouTubeDataParser.parse("src/data/youtubedata_malformed.json");
        List<YouTubeVideo> result = instance.parse(fileName);
    }

    /**
     * Test the FileNotFound Exception.
     *
     * @throws Exception when the file cannot be opened or cannot be parsed
     */
    @Test(expected = Exception.class)
    public void testFileNotFound() throws Exception {
        String fileName = "src/data/youtubedata_1.json";
        YouTubeDataParser instance = new YouTubeDataParser();
        List<YouTubeVideo> expResult = YouTubeDataParser.parse("src/data/youtubedata_1.json");
        List<YouTubeVideo> result = instance.parse(fileName);
    }

    /**
     * Test by sorting the YouTubeVideo object by Channel
     *
     * @throws Exception when file cannot be opened or cannot be parsed
     */
    @Test
    public void testSortByChannel() throws Exception {
        String fileName = "youtubedata_15_50.json";
        YouTubeDataParser instance = new YouTubeDataParser();
        List<YouTubeVideo> expResult = YouTubeDataParser.parse("youtubedata_15_50.json");
        List<YouTubeVideo> result = instance.parse(fileName);

        Collections.sort(expResult, new YouTubeVideoChannelComparator());
        Collections.sort(result, new YouTubeVideoChannelComparator());

        assertEquals(expResult.get(0).getChannel(), "AllHamishandAndyVids");
        assertEquals("AllHamishandAndyVids", result.get(0).getChannel());

    }

    /**
     * Test by sorting the YouTubeVideo object by Date
     *
     * @throws Exception when file cannot be opened or cannot be parsed
     */
    @Test
    public void testSortByDate() throws Exception {
        String fileName = "youtubedata_15_50.json";
        YouTubeDataParser instance = new YouTubeDataParser();
        List<YouTubeVideo> expResult = YouTubeDataParser.parse("youtubedata_15_50.json");
        List<YouTubeVideo> result = instance.parse(fileName);

        Collections.sort(expResult, new YouTubeVideoDateComparator());
        Collections.sort(result, new YouTubeVideoDateComparator());

        assertEquals(expResult.get(0).getDate(), "2008-02-11T22:59:52.000Z");
        assertEquals("2008-02-11T22:59:52.000Z", result.get(0).getDate());

    }

    /**
     * Test by sorting the YouTubeVideo object by View
     *
     * @throws Exception when file cannot be opened or cannot be parsed
     */
    @Test
    public void testSortByView() throws Exception {
        String fileName = "youtubedata_15_50.json";
        YouTubeDataParser instance = new YouTubeDataParser();
        List<YouTubeVideo> expResult = YouTubeDataParser.parse("youtubedata_15_50.json");
        List<YouTubeVideo> result = instance.parse(fileName);

        Collections.sort(expResult, new YouTubeVideoViewComparator());
        Collections.sort(result, new YouTubeVideoViewComparator());

        assertEquals(expResult.get(0).getViewCount(), 4406);
        assertEquals(4406, result.get(0).getViewCount());

    }

    /**
     * Test by sorting the YouTubeVideo object by Description
     *
     * @throws Exception when file cannot be opened or cannot be parsed
     */
    @Test
    public void testSortByDescription() throws Exception {
        String fileName = "youtubedata_15_50.json";
        YouTubeDataParser instance = new YouTubeDataParser();
        List<YouTubeVideo> expResult = YouTubeDataParser.parse("youtubedata_15_50.json");
        List<YouTubeVideo> result = instance.parse(fileName);

        Collections.sort(expResult, new YouTubeVideoDescriptionComparator());
        Collections.sort(result, new YouTubeVideoDescriptionComparator());

        assertEquals(expResult.get(0).getDescription(), "");
        assertEquals("", result.get(0).getDescription());
    }

    /**
     * Test the indexer and check whether it returns a sorted result and expects
     * the first word is "the[97]"
     *
     * @throws Exception when file cannot be opened or cannot be parsed
     */
    @Test
    public void testIndexer() throws Exception {
        String fileName = "youtubedata_15_50.json";
        YouTubeDataParser instance = new YouTubeDataParser();
        List<YouTubeVideo> expResult = YouTubeDataParser.parse("youtubedata_15_50.json");
        List<YouTubeVideo> result = instance.parse(fileName);
        List<YouTubeWordItem> wordItems = YouTubeVideoIndexer.index(result);

        YouTubeWordItem first = wordItems.get(0);

        assertEquals("the[97]", first.toString());
    }

}