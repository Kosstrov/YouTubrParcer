package youtubetrender;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * This class is a trending topic analyser for the list of videos.
 * @author Youngji Park & Konstantin Stepanov
 * @version 1.0 2020/05/18
 */

public class YouTubeVideoIndexer {

    /**
     * Index the word usage across the title and description of the videos.
     *
     * @param videoList a list of videos with List<YouTubeVideo> type
     * @return items sorted ArrayList of unique words
     */
    public static List<YouTubeWordItem> index(List<YouTubeVideo> videoList) {
        Map<String, YouTubeWordItem> words = new HashMap<String, YouTubeWordItem>();

        for (YouTubeVideo vid : videoList) {
            try {
                Scanner scanner = new Scanner(vid.getDescription());

                while (scanner.hasNext()) {
                    String word = scanner.next();

                    if (!word.isEmpty()) {
                        YouTubeWordItem wordItem = null;

                        if (words.containsKey(word)) {
                            wordItem = words.get(word);
                        } else {
                            wordItem = new YouTubeWordItem(word);
                            words.put(word, wordItem);
                        }

                        wordItem.getCount();
                        wordItem.add(vid);
                    }
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

        List<YouTubeWordItem> wordsList = new ArrayList<YouTubeWordItem>();

        for (String key : words.keySet()) {
            wordsList.add(words.get(key));
        }

        Collections.sort(wordsList);

        return wordsList;
    }
}
