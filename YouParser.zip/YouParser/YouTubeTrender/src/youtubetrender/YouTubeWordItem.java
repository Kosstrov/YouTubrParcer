package youtubetrender;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * triathlon
 */
public class YouTubeWordItem implements Comparable<YouTubeWordItem> {

    private String word;
    private int count;
    private Set<YouTubeVideo> videos;

    public YouTubeWordItem(String word) {
        this.word = word;
        count = 0;
        videos = new HashSet<YouTubeVideo>();
    }

    public void add(YouTubeVideo t) {
        count++;
        videos.add(t);
    }

    public int getCount() {
        return count;
    }

    public List<YouTubeVideo> getVideos() {
        List<YouTubeVideo> videosList = new ArrayList<YouTubeVideo>();
        for(YouTubeVideo video : videos) {
            videosList.add(video);
        }
        return videosList;
    }

    public String getWord() {
        return word;
    }

    public String toString() {
        return word + "[" + count + "]";
    }

    public int compareTo(YouTubeWordItem t) {
        return t.count - this.count;
    }
}
