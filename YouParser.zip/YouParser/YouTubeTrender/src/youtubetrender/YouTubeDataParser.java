/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package youtubetrender;
// This is the original YouTubeDataParser.
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.stream.JsonParsingException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 *
 */
public class YouTubeDataParser {

    private static String json;

    public static List<YouTubeVideo> parse(String json) throws YouTubeDataParserException {

        List<YouTubeVideo> youTubeVideoList = new ArrayList<>();
        JsonReader jsonReader = null;

        try {
            //read data
            jsonReader = Json.createReader(new FileInputStream(json));
            // throws java.io.FileNotFoundException
        } catch (FileNotFoundException exep) {
            throw new YouTubeDataParserException("File not found: " + json);
        }

        JsonObject jobj = null;
        try
        {
            jobj = jsonReader.readObject();
        }
        // throws java.io.JsonParsingException
        catch (JsonParsingException j) {
            throw new YouTubeDataParserException("Parsing exception: " + j.getMessage());
        }

        // read the values of the item field
        JsonArray items = jobj.getJsonArray("items");

        for (int i = 0; i < items.size(); i++) {
            JsonObject item = items.getJsonObject(i);
            String kind = item.getString("kind");
            String etag = item.getString("etag");

            JsonObject snippet = item.getJsonObject("snippet");

            // parsing to Youtubevideo
            String channelId = snippet.getString("channelId");
            String channelTitle = snippet.getString("channelTitle");
            String publishAt = snippet.getString("publishedAt");
            String title = snippet.getString("title");
            String description = snippet.getString("description");

            // parsing statistics
            JsonObject statistics = item.getJsonObject("statistics");
            int viewCount = Integer.valueOf(statistics.getString("viewCount"));

            YouTubeVideo youTubeVideo = new YouTubeVideo(channelTitle, publishAt, title, description, viewCount, channelId);

            // add to the list
            youTubeVideoList.add(youTubeVideo);
        }

        return youTubeVideoList;
    }

}
